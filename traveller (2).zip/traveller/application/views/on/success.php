<li class="active">About</li>
		</ol>
	</div>
	<!-- //breadcrumb -->
	<!--  about-page -->
	<div class="about">
		<div class="container"> 
			<h3 class="w3ls-title w3ls-title1">Pesanan Berhasil</h3>
			<div class="about-text">	
				<p>Terima kasih telah melakukan pemesanan di pemadam kelaparan, pesanan anda akan segera dikonfirmasi. Pembayaran dilakukan saat pengiriman. Untuk pertanyaan silahkan hubungi kontak kami. Terima kasih. </p> 
			</div>
		</div>
	</div>