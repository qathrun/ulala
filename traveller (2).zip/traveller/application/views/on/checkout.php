
			<li class="active">Detail Pengiriman</li>
		</ol>
	</div>
	<!-- //breadcrumb -->
	<!-- sign up-page -->
	<div class="login-page about">
		
		<div class="about">
        <div class="container"> 
            
        </div>
        </div>
		<div class="container"> 
			<h3 class="w3ls-title w3ls-title1">Alamat Pengiriman</h3>  
			<div class="login-agileinfo"> 
			
				<form method="post" action="<?php echo base_url("index.php/Member/inputOrder"); ?>"> 
					<input class="agile-ltext" type="text" name="username" value="<?php echo $this->session->userdata("username"); ?>" disabled="">
					
					<input class="agile-ltext" type="text" name="alamat" placeholder="Alamat Lengkap" required="">
					<input class="agile-ltext" type="text" name="tanggalkirim" placeholder="Tanggal Kirim (DD/MM/YYYY)" required="">
					<input class="agile-ltext" type="text" name="jamkirim" placeholder="Jam Kirim (24 jam)" required="">
					<div class="wthreelogin-text"> 
						<div class="clearfix"> </div>
					</div>   
					<input type="submit" value="Lanjutkan">
				</form>
			</div>	 
		</div>
	</div>
	<!-- //sign up-page -->  