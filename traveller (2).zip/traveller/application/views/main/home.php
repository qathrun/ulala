  		<div class="wthree-order">  
		<div class="container">
			
		</div>
	</div>
	<!-- //order -->    
	<!-- deals -->
	<div class="w3agile-deals">
		<div class="container">
			<h3 class="w3ls-title">Find yourself!</h3>
			<div class="dealsrow">
				<div class="col-md-6 col-sm-6 deals-grids">
					<div class="deals-left">
						<i class="fa fa-truck" aria-hidden="true"></i>
					</div> 
					<div class="deals-right">
						<h4>Accomodation</h4>
						<p>Butuh hotel? Atau tiket kereta? Semua ada!</p>
					</div> 
					<div class="clearfix"> </div>
				</div> 
				<div class="col-md-6 col-sm-6 deals-grids">
					<div class="deals-left">
						<i class="fa fa-building" aria-hidden="true"></i>
					</div> 
					<div class="deals-right">
						<h4>Paket Wisata</h4>
						<p>Temukan berbagai penawaran menarik, paket wisata murah dan dijamin seru! Book jadwalmu! </p>
					</div> 
					<div class="clearfix"> </div>
				</div>
				<div class="col-md-6 col-sm-6 deals-grids">
					<div class="deals-left">
						<i class="fa fa-users" aria-hidden="true"></i>
					</div> 
					<div class="deals-right">
						<h4>Travel Organizer</h4>
						<p>Kurang puas dengan paket wisata yang di tawarkan? Atur sendiri perjalananmu dengan Travel Organizer terpercaya! </p>
					</div>
					<div class="clearfix"> </div>
				</div> 
				
			</div>
		</div>
	</div>
	<!-- //deals --> 
	<!-- dishes -->