<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Member extends CI_Controller {
    public function __construct() {
        parent::__construct();
        if ($this->session->userdata('username') != null || $this->session->userdata('username') != ""){

        } else {
            redirect('Welcome');
        }
        $this->load->library('form_validation');
        $this->load->library('cart');
        $this->load->model('My_Model');
        $this->load->helper('url');
        $this->load->helper('form');
    }

    public function index(){
        $this->load->view('on/header');
        $this->load->view('main/home');
        $this->load->view('main/footer');
    }
    public function contact(){
        $this->load->view('on/header');
        $this->load->view('main/contact');
        $this->load->view('main/footer');
    }
    public function about(){
        $this->load->view('on/header');
        $this->load->view('main/about');
        $this->load->view('main/footer');
    }
    public function help(){
        $this->load->view('on/header');
        $this->load->view('main/help');
        $this->load->view('main/footer');
    }
    public function menu(){
        $this->load->view('on/header');
        $nasi = $this->My_Model->getMenu();
        $this->load->view('on/menu', array('nasi' => $nasi));

        $this->load->view('main/footer');
    }
    public function careers(){
        $this->load->view('on/header');
        $this->load->view('main/careers');
        $this->load->view('main/footer');
    }
    public function offers(){
        $this->load->view('on/header');
        $this->load->view('main/offers');
        $this->load->view('main/footer');
    }
    public function privacy(){
        $this->load->view('on/header');
        $this->load->view('main/privacy');
        $this->load->view('main/footer');
    }
    public function terms(){
        $this->load->view('on/header');
        $this->load->view('main/privacy');
        $this->load->view('main/footer');
    }
    public function cart(){
        $this->load->view('on/header');
        $this->load->view('on/cart');
        $this->load->view('main/footer');
    }

    public function checkout(){
        $this->load->view('on/header');
        $this->load->view('on/checkout');
        $this->load->view('main/footer');
    }
    public function success(){
        $this->load->view('on/header');
        $this->load->view('on/success');
        $this->load->view('main/footer');
    }
    public function logout(){
        $data = array('email','username','password');
        $this->session->unset_userdata($data);
        redirect('Welcome');
    }


    public function add_to_cart($id_pw){
        $product = $this->My_Model->find($id_pw);
        $data = array(
            'id'      => $product->id_pw,
            'qty'     => $product->kuota,
            'price'   => $product->harga,
            'name'    => $product->nama_paket
        );
        //$cart = ;
        $this->cart->insert($data);
        //print_r($data);
        redirect('Member/cart');
    }

    function editProduk($id_pw){
        $where = array ('id_pw'=>$id_pw);
        $b = $this->My_Model->updating('base_menu',$where);
        $data = array(
            'id_pw'=> $b[0]['id_pw'],
            'nama_paket'=> $b[0]['nama_paket'],
            'kuota'=> $b[0]['kuota'],
            'deskripsi'=> $b[0]['deskripsi'],
            'harga'=> $b[0]['harga'],
            'date'=> $b[0]['tanggal_berangkat'],
            'image'=> $b[0]['image']
        );
        $this->load->view('on/header');
        $this->load->view('on/detail',$data);
        $this->load->view('main/footer');
    }


    public function detail($id_pw){
        $where = array ('id_pw'=>$id_pw);
        $product = $this->My_Model->find($id_pw);
        $data = array(
            'nama'     => $product->nama_paket,
            'deskripsi'     => $product->deskripsi,
            'kuota'     => $product->kuota,
            'price'   => $product->harga,
            'date'    => $product->tanggal_berangkat
        );
        $this->load->view('on/header');
        $this->load->view('on/detail',$data);
        $this->load->view('main/footer');
    }

    public function clear_cart()
    {
        $this->cart->destroy();
        redirect('Member/cart');
    }
    public function inputOrder() {
        $alamat = $this->input->post('alamat');
        $tanggalkirim = $this->input->post('tanggalkirim');
        $jamkirim = $this->input->post('jamkirim');
        $idCustomer = $this->session->userdata('email');
        $isProcessed = $this->My_Model->process($idCustomer, $alamat, $tanggalkirim, $jamkirim);
        if($isProcessed) {
            $this->cart->destroy();
            redirect('Member/success');
        } else {
            $this->session->set_flashdata('error', 'Maaf, order Anda tidak dapat diproses');
        }
    }

    public function order(){
        $where = array ('id_pw'=>$id_pw);
        $ord = array(
            'username' => $this->input->post('username'),
            'id_pw' => $this->input->post('id_paket'),
            'jumlah_orang' => $this->input->post('jumlah_orang'),
            'addition' => $this->input->post('request'));

        $this->My_Model->addOrder($ord);
        $this->index();
    }

    function kirimemail()
    {
        $email = $this->input->post('ib_email');
        $nama = $this->input->post('ib_nama');
        $pesan = $this->input->post('ib_pesan');
        $url = $_SERVER['HTTP_REFERER'];
        $config = Array(
            'protocol' => 'smtp',
            'smtp_host' => 'ssl://smtp.googlemail.com',
            'smtp_port' => 465,
            'smtp_user' => 'maulidina.erica@gmail.com', 
            'smtp_pass' => 'bajudit0k0', 
            'mailtype' => 'html',
            'charset' => 'iso-8859-1',
            'wordwrap' => TRUE
        );
        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");
        $this->email->from($email);
        $this->email->to($this->input->post('ib_email')); 
        $this->email->subject('Pemadam Kelaparan');
        $this->email->message('terimakasih telah mengirimkan kritik dan saran anda, berikut adalah pesan anda : '.$pesan );
        if($this->email->send())
        {
            $masukdb = array(
                'ib_nama' => $this->input->post('ib_nama'),
                'ib_email' => $this->input->post('ib_email'),
                'ib_telfon' => $this->input->post('ib_telfon'),
                'ib_pesan' => $this->input->post('ib_pesan')
            );
            $this->My_Model->addKritik($masukdb);
            $this->index();
        }
        else
        {
            show_error($this->email->print_debugger());
        }

    }	

    public function kritik(){
        $pesan = array(
            'ib_nama' => $this->input->post('ib_nama'),
            'ib_email' => $this->input->post('ib_email'),
            'ib_telfon' => $this->input->post('ib_telfon'),
            'ib_pesan' => $this->input->post('ib_pesan')
        );

        $this->My_Model->addKritik($pesan);
        $this->index();
    }
}
?>