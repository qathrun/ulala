
<li class="active">Detail Paket</li>
</ol>
</div>
<div class="about">
    <div class="container"> 
        <div class="dealsrow">
            <div class="deals-right">
                <img src=" <?php echo base_url()."/assets/images/".$image; ?>" style="width: 500px;" >
            </div>
            <td><h3><?php echo $nama_paket;?>"</h3> </td>
            <br>
            <td><?php echo $deskripsi;?> </td>
            <div class="table-responsive">
                <table class="table table-hover">
                    <div align="right">

                        <tr>
                            <td>Kuota</td>
                            <td><?php echo $kuota;?> </td>
                        </tr>
                        <tr>
                            <td>Tanggal Keberangkat</td>
                            <td><?php echo $date;?> </td>
                        </tr>
                        <tr>
                            <td>Harga</td>
                            <td><?php echo $harga;?> </td>
                        </tr>
                    </div>

                    <tr>

                    </tr>
                </table>
            </div>
            </form>
    </div>

    <div align="center">
        <?= anchor('Member/menu','Lihat yang lain',['class'=>'btn btn-primary']) ?> 
        <?= anchor('Member/checkout','Book',['class'=>'btn btn-success']) ?>
    </div>   

</div>
</div>