
			<li class="active">Detail Pengiriman</li>
		</ol>
	</div>
	<!-- //breadcrumb -->
	<!-- sign up-page -->
	<div class="login-page about">
		
		<div class="about">
        <div class="container"> 
            
        </div>
        </div>
		<div class="container"> 
			<h3 class="w3ls-title w3ls-title1">Detail Pemesanan</h3>  
			<div class="login-agileinfo"> 
			
				<form method="post" action="<?php echo base_url("index.php/Member/order"); ?>"> 
					<input class="agile-ltext" type="text" name="username" value="<?php echo $this->session->userdata("username"); ?>" disabled="">
					<input class="agile-ltext" type="text" name="id_paket" placeholder="Paket" required="">
					<input class="agile-ltext" type="text" name="jumlah_orang" placeholder="Jumlah Orang" required="">
					<input class="agile-ltext" type="text" name="request" placeholder="Request Tambahan" required="">
					<div class="wthreelogin-text"> 
						<div class="clearfix"> </div>
					</div>   
					<input type="submit" value="Lanjutkan">
				</form>
			</div>	 
		</div>
	</div>
	<!-- //sign up-page -->  