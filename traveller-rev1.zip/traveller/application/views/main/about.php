
			<li class="active">About</li>
		</ol>
	</div>
	<!-- //breadcrumb -->
	<!--  about-page -->
	<div class="about">
		<div class="container"> 
			<h3 class="w3ls-title w3ls-title1">Tentang Kami</h3>
			<div class="about-text">	
				<p>Traveller adalah menjawab kebutuhan liburan anda yang tidak terencana. Dengan Traveller, travelling akan lebih mudah, nyaman dan memuaskan. Kami menyediakan berbagai menu liburan yang anda inginkan. Salah satunya adalah menu paket yang dijamin lebih hemat dan lebih menarik.</p> 
				<div class="ftr-toprow">
					<div class="col-md-4 ftr-top-grids">
						<div class="ftr-top-left">
							<i class="fa fa-truck" aria-hidden="true"></i>
						</div> 
						<div class="ftr-top-right">
							<h4>Free Acomondation</h4>
							<p>Anda dapat mendapatkan layanan hotel dan transportasi gratis selama di area tempat liburan</p>
						</div> 
						<div class="clearfix"> </div>
					</div> 
					<div class="col-md-4 ftr-top-grids">
						<div class="ftr-top-left">
							<i class="fa fa-user" aria-hidden="true"></i>
						</div> 
						<div class="ftr-top-right">
							<h4>Fast Response</h4>
							<p>Customer service yang ramah dan fast response pada jam kerja</p>
						</div> 
						<div class="clearfix"> </div>
					</div>
					<div class="col-md-4 ftr-top-grids">
						<div class="ftr-top-left">
							<i class="fa fa-thumbs-o-up" aria-hidden="true"></i>
						</div> 
						<div class="ftr-top-right">
							<h4>Base on Quality</h4>
							<p>Kami dapat menjamin tempat wisata dan segala fasilitas yang kami berikan memuaskan</p>
						</div>
						<div class="clearfix"> </div>
					</div> 
					<div class="clearfix"> </div>
				</div> 
				<div class="clearfix"> </div>
			</div>
			<br>
			<br>
			
			
				<h3 align="center"; class="w3ls-title w3ls-title1">Bagaimana cara booking?</h3>
				<div align="center">
				<ul>
					<ol> Cukup masuk menggunakan akun anda </ol>
					<ol> pilih paket yang anda inginkan </ol>
					<ol> isi formulir pembelian </ol>	
					<ol> lakukan pembayaran </ol>
				</ul>
				</div>

			<br>
			<br>
				<h3 align="center"; class="w3ls-title w3ls-title1">Hubungi Kami</h3>
				<div align="center">
					<ul>
					<ol>Alamat traveller | Jl. Keputih Tegal Timur Gg.2 No. 15, Surabaya, Jawa Timur</ol>
					<ol>Nomer Telfon | +62 878 5563 2901</ol>
					</ul>
				</div>

		</div>
	</div>