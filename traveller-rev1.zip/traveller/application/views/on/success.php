<li class="active">About</li>
		</ol>
	</div>
	<!-- //breadcrumb -->
	<!--  about-page -->
	<div class="about">
		<div class="container"> 
			<h3 class="w3ls-title w3ls-title1">Pesanan Berhasil</h3>
			<div class="about-text">	
				<p>Terima kasih telah melakukan Booking paket wisata melalui Traveller. Silahkan melakukan pembayaran untuk proses validasi e-ticket</p> 
			</div>
		</div>
	</div>